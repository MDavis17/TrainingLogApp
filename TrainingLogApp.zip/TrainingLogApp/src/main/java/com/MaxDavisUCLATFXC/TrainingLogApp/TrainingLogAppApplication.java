package com.MaxDavisUCLATFXC.TrainingLogApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainingLogAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainingLogAppApplication.class, args);
	}
}
